process_file :-
    open('Interview_input.txt', read, S),

    read_line_to_codes(S, Fs),
    atom_codes(Fa, Fs),
    atomic_list_concat(Elems, ',', Fa),

    repeat,
    read_line_to_codes(S, L),
    read_from_codes(L, T),
    ( T == end_of_file -> close(S)
    ; apply_line(T, Elems), fail
    ).

apply_line(T, Es) :-
    T =.. [F,K,As],
    maplist(out_line(F, K), Es, As).

out_line(F, K, E, A) :-
    T =.. [F, K, E, A],
    writeln(T).
