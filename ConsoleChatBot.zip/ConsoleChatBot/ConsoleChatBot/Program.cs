﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleChatBot
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputValue = "";
            string outputValue = "";
            int questionCount = 0;

            Random rdn = new Random();

            int openingQuestion = rdn.Next(1, 4);

            switch (openingQuestion)
            {
                case 1:
                    Console.WriteLine("Hello. How are you today?");
                    break;
                case 2:
                    Console.WriteLine("Hello. How are you feeling?");
                    break;
                case 3:
                    Console.WriteLine("Hey, how are you doing today?");
                    break;
            }

            inputValue = Console.ReadLine();

            //Console.WriteLine("Hello, how are you today? Looking forward to the interview?");
            //inputValue = Console.ReadLine();

            if (inputValue.Contains("good") && inputValue.Contains("you?"))
            {
                System.Threading.Thread.Sleep(5000);
                Console.WriteLine("Im good, thank you. Lets get started with the interview shall we?");
            }
            if (inputValue.Contains("nervous"))
            {
                System.Threading.Thread.Sleep(5000);
                Console.WriteLine("No need to be nervous, im sure you've got the right skills for the job, so just relax. Lets get started");
            }
            if (inputValue.Contains("yourself?"))
            {
                System.Threading.Thread.Sleep(4000);
                Console.WriteLine("Im good thanks, lets gets started with the interview.");
            }
            else
            {
                System.Threading.Thread.Sleep(3000);
                Console.WriteLine("Lets get started with the interview");
            }

            int firstQuestion = rdn.Next(1, 4);
            switch(firstQuestion)
            {
                case 1:
                    System.Threading.Thread.Sleep(4000);
                    Console.WriteLine("So firstly, tell me about when you've demostrated good team working skills?");
                    break;
                case 2:
                    System.Threading.Thread.Sleep(4000);
                    Console.WriteLine("So when have you worked well in a team?");
                    break;
                case 3:
                    System.Threading.Thread.Sleep(4000);
                    Console.WriteLine("Can you tell me of a time when you succesfully worked in a team?");
                    break;
            }
            inputValue = Console.ReadLine();

            if(inputValue.Contains("leader") && inputValue.Contains("delegated"))
            {
                System.Threading.Thread.Sleep(6000);
                Console.WriteLine("So you were a leader of a team? How well did that go?");
            }
            if(inputValue.Contains("team worker") && inputValue.Contains("plan"))
            {
                System.Threading.Thread.Sleep(4000);
                Console.WriteLine("So would your team members be able to trust you to do work and get it completed on time?");
            }
        }
    }
}
